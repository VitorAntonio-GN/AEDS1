# 🛸 Sistema-Planetario-Interativo 🌌
Projeto desenvolvido para praticar conceitos de structs, ponteiros, alocação dinâmica de memória e manipulação de arquivos em C. O programa permite criar, gerenciar, salvar e carregar sistemas solares compostos por estrelas e planetas com dados personalizados via menu interativo. 

## Contexto Acadêmico 🎓
Este projeto foi desenvolvido como parte das atividades da **monitoria de Algoritmos e Estruturas de Dados I**, no curso de **Engenharia da Computação** da **UEMG**, Unidade Divinópolis.

> [!NOTE]
> **Acesse o diretório completo do projeto aqui:** [Sistema Solar Interativo](https://github.com/DiegoAntonio-M/Monitoria-AEDS1/blob/main/Projetos%20Sugeridos/SistemaSolar.md), no GitHub, sugerido pelo monitor [Diego Antônio](https://github.com/DiegoAntonio-M).


## Conceitos envolvidos 📘
- Structs compostas;
- Arrays dinâmicos;
- Alocação de memória;
- Manipulação de arquivos binários;
- Organização modular de código.

## Objetivos 🎯
- Praticar `structs` e `ponteiros`;
- Gerenciar memória com `malloc`/`realloc`/`free`;
- Trabalhar com arquivos binários (`fwrite`, `fread`);
- Criar um `menu interativo` com `persistência de dados`.

## Aprendizados 📚
Durante o desenvolvimento aprendi a:
- Manipular ponteiros de structs;
- Trabalhar com arrays dinâmicos realocados;
- Usar arquivos binários para salvar dados complexos.

## Estrutura de Diretórios 🗂️
```
Sistema-Planetario-Interativo/
├── dados/
│   └── sistema_planetario.bin      // -> Arquivo binário do sistema
├── LICENSE                         // -> Licença do MIT
├── README.md                       // -> Documentação do projeto
└── main.c                          // -> Programa principal com todas as funções
```

## Autor ✍️
Desenvolvido por [Vítor Antônio](https://github.com/VitorAntonio-GN).

## Licensa 📄
MIT License, veja o arquivo LICENSE para mais detalhes.
